﻿using System;

namespace Lesson1_Task5._6
{
    class control
    {
        public void Pause()
        {
            Console.ReadKey();
        }
    }
}
